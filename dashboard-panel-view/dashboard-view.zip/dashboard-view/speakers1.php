<?php
ob_start();
session_start();
include("inc/config.php");
if($_SESSION['sess_member']=="")
{
	header('location:index.php');
}
@$mem_id = @$_SESSION['sess_member']; 
@$id = @$_GET['id'];
//--------------------DELETE -----------------------		
					
			if($id!="")
			{
			        @$q_fres = mysqli_query($con,"select *from Speakers_tblstr_d where id='$id'");
					@$fres_rw = mysqli_fetch_assoc($q_fres);
					//-----------------------------
					@$d_photo = "photos/".@$fres_rw['photo'];					
					//-----------------------------
					unlink($d_photo);								
					//-----------------------------
					@$cms_del = "delete from Speakers_tblstr_d where id='$id'";
					@$del_res  =mysqli_query($con,$cms_del);
					header("location:speakers.php");
			}	
			
?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <title>Speakers | Dashboard</title>

  <!-- General CSS Files -->
  <link rel="stylesheet" href="assets/modules/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/modules/fontawesome/css/all.min.css">

  <!-- CSS Libraries -->
  <link rel="stylesheet" href="assets/modules/jqvmap/dist/jqvmap.min.css">
  <link rel="stylesheet" href="assets/modules/summernote/summernote-bs4.css">
  <link rel="stylesheet" href="assets/modules/owlcarousel2/dist/assets/owl.carousel.min.css">
  <link rel="stylesheet" href="assets/modules/owlcarousel2/dist/assets/owl.theme.default.min.css">

  <!-- Template CSS -->
  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="stylesheet" href="assets/css/components.css">
  <script type="text/javascript">
function cmsdel(id)
{		
    var stat = confirm("Are you sure you want to delete ?");	
	if(stat!="")
	{
			if(id!="")
			{
			     location.href="speakers.php?id="+id;
			}
	}
	else
		{ 
		}
}
</script>  
<style>
#page_list li
   {
    padding:16px;
    background-color:#f9f9f9;
    border:1px dotted #ccc;
    cursor:move;
    margin-top:12px;
   }
   #page_list li.ui-state-highlight
   {
    padding:24px;
    background-color:#ffffcc;
    border:1px dotted #ccc;
    cursor:move;
    margin-top:12px;
   }
   </style>
</head>

<body>

  <div id="app">
    <?php include('header.php');?>
    <?php include('sidemenu.php');?>
        <!-- Main Content -->
      <div class="main-content">
        <section class="section">
           <div class="section-header">
            <h1> Speakers</h1>
            <div class="section-header-breadcrumb">
              <div class="breadcrumb-item active"><a href="#">Dashboard</a></div>
              <div class="breadcrumb-item"><a href="#"> Speakers</a></div>
             <!-- <div class="breadcrumb-item"> </div>-->
            </div>
          </div>
		  <div class="row">
		     <div class="col-md-6">&nbsp;
			 </div>
			 <div class="col-md-4">&nbsp;
			 </div>
             <div class="col-md-2">
			 
			 <a href="add-speakers.php"  class="prs1 btn btn-icon icon-left btn-info">
			 
			 <b> <i class="fas fa-plus"></i>Add Speakers</b></a>
			 </div>
			 </div>
			 <br>
          <div class="row">
             <div class="col-12 mb-4">
                <div class="card-body p-0">
                    <div class="table-responsive">
                      <table class="table table-striped table-md">
                        <tr>
                          <th>Sno</th>
                          <th>Name</th>
                          <th>Photo</th>
                          <th>Affiliation</th>
                          <th>Biography</th>
                          <th>Edit</th>
                          <th>Delete</th>
                        </tr>
						<tbody class="list-unstyled" id="page_list">
						 <?php
				$query  = "SELECT *FROM Speakers_tblstr_d WHERE user='".$_SESSION['sess_member']."' ORDER BY position_order";
				$result =  mysqli_query($con,$query);	
				//$i=1;		
				if(mysqli_num_rows($result)>0)
				{	
			?>
			
			 <?php
				while($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
				{
					?>
				           <tr  id="<?php echo @$row['id']; ?>">
                          <td><?php echo @$row['id']; ?></td>
                          <td><?php echo @$row['name']; ?></td>
                          <td><?php  if(@$row['photo']!="")  { ?> <img src="speakers_photos/<?php echo @$row['photo']; ?>" class="img-circle" width="50" height="50"/><?php  } else { echo ""; } ?></td>
                          <td><?php 
	  $affi=strlen($row['affiliation']);
	  if($affi>80){
	  echo "...";
	  }
	  else{
	  echo $row['affiliation'];
	  }
	  ?></td>
                          <td><?php echo  substr($row['biography'],0,40)."..."; ?></td>
                          <td><a href="add-speakers.php?id=<?php echo @$row['id']; ?>" class="prs1 btn btn-icon btn-primary"><i class="far fa-edit"></i></a></td>
                          <td><a href="javascript:cmsdel('<?php echo @$row['id']; ?>')" class="prs1 btn btn-icon btn-danger"><i class="fas fa-trash"></i></a></td>
                           <?php 
				//$i=$i+1; 
				}  } else { ?>
				<td><font color="#FF0000">No records</font></td>
				<?php } ?>
				</tr> 
                        </tbody>
 <input type="hidden" name="page_order_list" id="page_order_list" />
										
                      </table>
                    </div>
                  </div>
              </div>
          </div>
         
        </section>
      </div>
      <?php include('footer.php');?>
    </div>
  </div>

  
  <!-- General JS Scripts -->
  <script src="assets/modules/jquery.min.js"></script>
  <script src="http://code.jquery.com/jquery-1.10.2.js"></script>
  <script src="http://code.jquery.com/ui/1.11.2/jquery-ui.js"></script>
<script src="assets/modules/popper.js"></script>
  <script src="assets/modules/tooltip.js"></script>
  <script src="assets/modules/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/modules/nicescroll/jquery.nicescroll.min.js"></script>
  <script src="assets/modules/moment.min.js"></script>
  <script src="assets/js/stisla.js"></script>
  
  <!-- JS Libraies -->
  <script src="assets/modules/jquery.sparkline.min.js"></script>
  <script src="assets/modules/chart.min.js"></script>
  <script src="assets/modules/owlcarousel2/dist/owl.carousel.min.js"></script>
  <script src="assets/modules/summernote/summernote-bs4.js"></script>
  <script src="assets/modules/chocolat/dist/js/jquery.chocolat.min.js"></script>

  <!-- Page Specific JS File -->
  
  <!-- Template JS File -->
  <script src="assets/js/scripts.js"></script>
  <script src="assets/js/custom.js"></script>
  <script>
$(document).ready(function(){
 $( "#page_list" ).sortable({
  placeholder : "ui-state-highlight",
  update  : function(event, tbody)
  {
   var page_id_array = new Array();
   $('#page_list tr').each(function(){
    page_id_array.push($(this).attr("id"));
   });
   $.ajax({
    url:"ajaxPro2.php",
    method:"POST",
    data:{page_id_array:page_id_array},
    success:function(data)
    {
     alert(data);
    }
   });
  }
 });

});
</script>

 <!-- <script type="text/javascript">
    $( ".row_position" ).sortable({
        delay: 150,
        stop: function() {
            var selectedData = new Array();
            $('.row_position>tr').each(function() {
                selectedData.push($(this).attr("id"));
            });
            updateOrder(selectedData);
        }
    });


    function updateOrder(data) {
        $.ajax({
            url:"ajaxPro.php",
            type:'post',
            data:{position:data},
            success:function(){
                alert('your change successfully saved');
            }
        })
    }
</script>-->
</body>
 
</html>