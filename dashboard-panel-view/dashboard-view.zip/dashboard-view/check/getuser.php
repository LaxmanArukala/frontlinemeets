<?php
echo "<table cellpadding='0' cellspacing='6' width='700'>
	<tbody>
		<tr>
			<td bgcolor='#555555' class='heading' colspan='2' height='22px;' style='padding-left:6px;'>
				<strong><span style='color:#fff0f5;'>Track 1: Molecular Modeling</span></strong></td>
		</tr>
		<tr>
			<td bgcolor='#f5f5f5' class='smalltext' height='18px;' width='76'>
				Track 1-1:</td>
			<td bgcolor='#f5f5f5' class='smalltext' width='604'>
				Molecular Dynamics in Drug Designing</td>
		</tr>
	</tbody>
</table>";
?>