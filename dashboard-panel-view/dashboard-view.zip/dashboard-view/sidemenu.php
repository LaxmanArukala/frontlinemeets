<style>
.clr{
color:#000 !important;
font-weight:900 !important;
}
.clr2{
color:#000 !important;
}	
.form-control, .input-group-text, .custom-select, .custom-file-label {
    background-color: #fdfdff !important;
    border-color: #3abaf4 !important;
}
</style>
<div class="main-sidebar sidebar-style-2">
        <aside id="sidebar-wrapper">
          <div class="sidebar-brand">
            <a href="home.php">MedWide Conferences </a>
          </div>
          <div class="sidebar-brand sidebar-brand-sm">
            <a href="home.php">MedWide Conferences </a>
          </div>
          <ul class="sidebar-menu">
            <li class="menu-header clr"><b>Dashboard</b></li>
			
			<li class="dropdown">
              <a href="#" class="nav-link has-dropdown clr2"><i class="fas fa-home"></i> <span>Home Page Content</span></a>
              <ul class="dropdown-menu">
                <li><a class="nav-link clr2" href="about.php"> About Conference</a></li>
                <li><a class="nav-link clr2" href="banners.php"> Banners</a></li>
                <li><a class="nav-link clr2" href="chair-cochair.php"> Chair & Co-Chair</a></li>
               </ul>
            </li>
			
            
            <li class="menu-header clr">Conference Highlights</li>
             
                <li><a class="nav-link clr2" href="conference_highlights.php"><i class="far fa-file-alt"></i> Conference Highlights</a></li> 
				
				<li class="menu-header clr">Sessions</li>
             
                <li><a class="nav-link clr2" href="topics.php"><i class="far fa-file-alt"></i> Sessions</a></li>
            <li class="menu-header clr">Conference Information</li>  
            <li><a class="nav-link clr2" href="important-dates.php"><i class="fas fa-th"></i> <span>Important Information</span></a></li>
            <li><a class="nav-link clr2" href="schedule.php"><i class="far fa-file-alt"></i> <span>Program Schedule</span></a></li>
			<li class="menu-header clr">Conference Speakers</li>
			<li><a class="nav-link clr2" href="committee.php"><i class="fas fa-users"></i> <span>Committee</span></a></li>
            <li class="dropdown">
              <a href="#" class="nav-link has-dropdown clr2"><i class="fas fa-user-tie"></i> <span>Speakers</span></a>
              <ul class="dropdown-menu">
                <li><a class="nav-link clr2" href="speakers.php"> Speakers</a></li>
                <li><a class="nav-link clr2" href="plenary-speakers.php">Plenary Speakers</a></li>
                <li><a class="nav-link clr2" href="keynote-speakers.php">Keynote Speakers</a></li>
                <li><a class="nav-link clr2" href="invited-speakers.php">Invited Speakers</a></li>
                <li><a class="nav-link clr2" href="featured-speakers.php">Featured Speakers</a></li>
                </ul>
            </li>
			<li class="menu-header clr">Pdf's</li>
             
                <li><a class="nav-link clr2" href="upload-pdfs.php"><i class="fas fa-file-pdf"></i> Upload Pdf's</a></li>
            <li class="menu-header clr">Metatags</li>
			 <li><a class="nav-link clr2" href="conff_meta_tags.php"><i class="fas fa-globe"></i> Metatags</a></li>
            <li class="dropdown">
              <a href="#" class="nav-link has-dropdown clr2"><i class="fas fa-file-alt"></i> <span>Inner Pages</span></a>
              <ul class="dropdown-menu">
               <li><a class="nav-link clr2" href="faqs.php">FAQ'S</a></li>  
                     <li><a class="nav-link clr2" href="guidelines.php">Guidelines</a></li>               
                     <li><a class="nav-link clr2" href="terms-conditions.php">Terms and Conditions</a></li>               
				     
				             </ul>
            </li> 
            <li class="dropdown">
              <a href="#" class="nav-link has-dropdown clr2"><i class="fas fa-handshake"></i> <span>Sponsors & Partners</span></a>
              <ul class="dropdown-menu">
                <li><a class="nav-link clr2" href="exhibitors-sponsors.php">Exhibitors & Sponsors</a></li>
                <li><a class="nav-link clr2" href="media_partners.php">Media Partner</a></li>
                <li><a class="nav-link clr2" href="collaborations.php">Collaborations Partner</a></li>
                <li><a class="nav-link clr2" href="universites.php">University Partner</a></li>
               </ul>
            </li>
			<li class="dropdown">
              <a href="#" class="nav-link has-dropdown clr2"><i class="fas fa-handshake"></i> <span>Journals Publishing & Conference Proceedings</span></a>
              <ul class="dropdown-menu">
                <li><a class="nav-link clr2" href="supporting-journals.php">Supporting Journals </a></li>
                <li><a class="nav-link clr2" href="publications.php">Publications </a></li>
                <li><a class="nav-link clr2" href="benefits-of-publications.php">Benefits of Publications </a></li>
                 </ul>
            </li>
			<li class="menu-header clr">Venue Details</li>
			 <li class="dropdown">
              <a href="#" class="nav-link has-dropdown clr2"><i class="fas fa-map-marker-alt"></i> <span>Venue & Hospitality</span></a>
              <ul class="dropdown-menu">
                <li><a class="nav-link clr2" href="venue-hospitality.php">About Venue</a></li>
                <li><a class="nav-link clr2" href="attractions.php">Venue Attractions</a></li>
               </ul>
            </li>
			
			<li class="menu-header clr">Abstracts</li>
			<li><a class="nav-link beep beep-sidebar clr2" href="view-abstracts.php"><i class="fas fa-book-open"></i> View Abstracts</a></li>
			<li class="menu-header clr clr2">Registrations</li>
			<li><a class="nav-link beep beep-sidebar clr2" href="registrations.php"><i class="fas fa-money-check"></i> View Registrations</a></li>
			
			
			
           </ul>

          <!--<div class="mt-4 mb-4 p-3 hide-sidebar-mini">
            <a href="#" class="btn btn-primary btn-lg btn-block btn-icon-split">
              <i class="fas fa-rocket"></i>  
            </a>
          </div> -->       
		  </aside>
      </div>