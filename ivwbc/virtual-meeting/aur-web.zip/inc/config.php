<?php
 $con1 = mysqli_connect("localhost","u216678667_8626_aus","Mx*kY+M9~kAUR_S","u216678667_auragen_D");
if (!$con1) {
    die("Connection failed: " . mysqli_connect_error($con1));
}
?>