<?php
$site_url="https://www.auragengroup.com/imbn/virtual-meeting";
$adminemail="auragengroup@gmail.com";
$regemail="auragengroup@gmail.com";
?>
