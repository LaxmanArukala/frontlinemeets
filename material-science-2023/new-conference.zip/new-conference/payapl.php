<?php
$amount=$_POST['amount'];

echo $amount;
?>